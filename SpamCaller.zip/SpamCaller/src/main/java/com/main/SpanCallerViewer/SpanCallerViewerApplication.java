package com.main.SpanCallerViewer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpanCallerViewerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpanCallerViewerApplication.class, args);
	}

}

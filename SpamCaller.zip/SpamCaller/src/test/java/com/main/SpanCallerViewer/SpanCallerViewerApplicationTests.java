package com.main.SpanCallerViewer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpanCallerViewerApplicationTests {

	@Test
	void contextLoads() {
	}

}
